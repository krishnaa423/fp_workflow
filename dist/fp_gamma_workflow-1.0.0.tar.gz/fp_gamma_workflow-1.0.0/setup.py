from setuptools import setup, find_packages

setup(
    name='fp_gamma_workflow',
    version='1.0.0',
    author='Krishnaa Vadivel',
    author_email='krishnaa.vadivel@yale.edu',
    description='First principles QE and BGW workflow',
    url='https://github.com/krishaa423/fp_gamma_workflow',
    packages=find_packages(),
)
